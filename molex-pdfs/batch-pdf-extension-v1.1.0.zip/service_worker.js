
let state = {
  running: false,
  paused: false,
  lines: [],
  folder: 'batch',
  currentIndex: 0,
  total: 0,
  tabId: null,
  waitMs: 5000,
  breakEvery: 0,
  breakMs: 0,
  contentReady: false
};

function sanitizeFilename(s) {
  return s.replace(/[\\/:*?"<>|]/g, '_');
}

function sendProgress(status) {
  chrome.runtime.sendMessage({
    type: 'BATCH_PROGRESS',
    payload: {
      running: state.running,
      paused: state.paused,
      current: state.currentIndex,
      total: state.total,
      status
    }
  });
}

function wait(ms) {
  return new Promise(res => setTimeout(res, ms));
}

async function ensureContentReady() {
  if (!state.tabId) return false;
  try {
    const ping = await chrome.tabs.sendMessage(state.tabId, { type: 'PING_CONTENT_READY' });
    if (ping && ping.ready) {
      state.contentReady = true;
      return true;
    }
  } catch {}
  try {
    await chrome.scripting.executeScript({
      target: { tabId: state.tabId },
      files: ['content.js']
    });
    state.contentReady = true;
    return true;
  } catch (e) {
    sendProgress('Failed to inject content script: ' + e);
    return false;
  }
}

async function runOne(value) {
  sendProgress(`Paste & click: ${value}`);

  const ok = await ensureContentReady();
  if (!ok) { await wait(500); return; }

  const setClick = await chrome.tabs.sendMessage(state.tabId, { type: 'SET_AND_CLICK', payload: { value } })
    .catch(err => ({ ok:false, error: String(err) }));

  if (!setClick || !setClick.ok) {
    sendProgress(setClick?.error || 'Failed to set/click');
    await wait(1000);
    return;
  }

  // Fixed wait (user-configured)
  sendProgress(`Waiting ${Math.round(state.waitMs/1000)}s for: ${value}`);
  await wait(state.waitMs);

  // Clear after waiting
  const ok2 = await ensureContentReady();
  if (ok2) {
    await chrome.tabs.sendMessage(state.tabId, { type: 'CLEAR_ONLY' }).catch(()=>{});
  }
}

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (!state.running) { suggest(); return; }
  // name based on the current item (index-1 because we increment after completion)
  const idx = Math.min(state.currentIndex, state.lines.length-1);
  const value = state.lines[idx];
  const name = sanitizeFilename(String(value)) + '.pdf';
  const path = sanitizeFilename(state.folder) + '/' + name;
  suggest({ filename: path, conflictAction: 'overwrite' });
});

async function waitWhilePaused() {
  while (state.running && state.paused) {
    await wait(250);
  }
}

async function runBatch() {
  state.running = true;
  state.currentIndex = 0;
  state.total = state.lines.length;

  while (state.running && state.currentIndex < state.total) {
    await waitWhilePaused();
    if (!state.running) break;

    const value = state.lines[state.currentIndex];
    await runOne(value);

    // notify popup to remove the processed item
    chrome.runtime.sendMessage({ type: 'ITEM_DONE', payload: { value } });

    state.currentIndex += 1;
    sendProgress(`Completed: ${value}`);

    // scheduled auto-break
    if (state.breakEvery > 0 && state.breakMs > 0 && (state.currentIndex % state.breakEvery === 0) && (state.currentIndex < state.total)) {
      state.paused = true;
      chrome.runtime.sendMessage({ type: 'BATCH_PAUSED', payload: { current: state.currentIndex, total: state.total, reason: `Auto break for ${Math.round(state.breakMs/1000)}s` } });
      await wait(state.breakMs);
      if (!state.running) break;
      state.paused = false;
      chrome.runtime.sendMessage({ type: 'BATCH_RESUMED', payload: { current: state.currentIndex, total: state.total } });
    }
  }

  if (state.running) {
    state.running = false;
    chrome.runtime.sendMessage({ type: 'BATCH_DONE', payload: { total: state.total } });
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'START_BATCH') {
    const { lines, folder, tabId, waitMs, breakEvery, breakMs } = msg.payload;
    state.lines = lines.slice(); // copy
    state.folder = folder || 'batch';
    state.tabId = tabId;
    state.waitMs = typeof waitMs === 'number' ? waitMs : 5000;
    state.breakEvery = typeof breakEvery === 'number' ? breakEvery : 0;
    state.breakMs = typeof breakMs === 'number' ? breakMs : 0;
    state.currentIndex = 0;
    state.total = state.lines.length;
    state.running = true;
    state.paused = false;
    state.contentReady = false;
    sendProgress('Starting…');
    runBatch();
  }

  if (msg?.type === 'STOP_BATCH') {
    state.running = false;
    state.paused = false;
    chrome.runtime.sendMessage({
      type: 'BATCH_STOPPED',
      payload: { current: state.currentIndex, total: state.total }
    });
  }

  if (msg?.type === 'TOGGLE_PAUSE') {
    if (!state.running) return;
    state.paused = !state.paused;
    if (state.paused) {
      chrome.runtime.sendMessage({ type: 'BATCH_PAUSED', payload: { current: state.currentIndex, total: state.total, reason: 'Paused by user' } });
    } else {
      chrome.runtime.sendMessage({ type: 'BATCH_RESUMED', payload: { current: state.currentIndex, total: state.total } });
    }
  }
});
