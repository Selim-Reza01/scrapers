// Ensure we only register listeners once per tab
if (!window.__BATCH_PDF_SINGLETON__) {
  window.__BATCH_PDF_SINGLETON__ = true;

  function setNativeValue(element, value) {
    const lastValue = element.value;
    element.value = value;
    const event = new Event('input', { bubbles: true });
    const tracker = element._valueTracker;
    if (tracker) tracker.setValue(lastValue);
    element.dispatchEvent(event);
  }

  function elements() {
    const textarea = document.querySelector('#pn_data');
    const btn = document.querySelector('#pdfgenerate');
    if (!textarea || !btn) {
      return { ok:false, error: 'Could not find #pn_data and/or #pdfgenerate on this page.' };
    }
    return { ok:true, textarea, btn };
  }

  async function setAndClick(value) {
    const els = elements();
    if (!els.ok) return els;
    setNativeValue(els.textarea, '');
    await new Promise(r => setTimeout(r, 50));
    setNativeValue(els.textarea, value);
    await new Promise(r => setTimeout(r, 100));
    // Single click only
    els.btn.click();
    return { ok:true };
  }

  async function clearOnly() {
    const els = elements();
    if (!els.ok) return els;
    setNativeValue(els.textarea, '');
    return { ok:true };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === 'SET_AND_CLICK') {
      setAndClick(msg.payload.value).then(sendResponse);
      return true;
    }
    if (msg?.type === 'CLEAR_ONLY') {
      clearOnly().then(sendResponse);
      return true;
    }
    if (msg?.type === 'PING_CONTENT_READY') {
      sendResponse({ ok:true, ready:true });
      return true;
    }
  });
}
