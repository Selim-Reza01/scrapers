
function parseLines(raw) {
  return raw.split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean);
}

function setUI({running, paused, progress, total, status}) {
  document.getElementById('start').disabled = running;
  document.getElementById('pauseResume').disabled = !running;
  document.getElementById('pauseResume').textContent = paused ? 'Resume' : 'Pause';
  document.getElementById('stop').disabled = !running;
  const prog = document.getElementById('progress');
  const doneCount = document.getElementById('doneCount');
  const totalCount = document.getElementById('totalCount');
  const statusEl = document.getElementById('status');
  prog.max = total || 0;
  prog.value = progress || 0;
  doneCount.textContent = progress || 0;
  totalCount.textContent = total || 0;
  statusEl.textContent = status || (running ? (paused ? 'Paused' : 'Running') : 'Idle');
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  return tab?.id;
}

document.getElementById('start').addEventListener('click', async () => {
  const dataInput = document.getElementById('dataInput').value;
  const folder = document.getElementById('folderInput').value.trim();
  const waitSeconds = parseFloat(document.getElementById('waitSeconds').value) || 0;
  const breakEvery = parseInt(document.getElementById('breakEvery').value || '0', 10);
  const breakSeconds = parseInt(document.getElementById('breakSeconds').value || '0', 10);
  const lines = parseLines(dataInput);
  if (!lines.length) { alert('Please enter at least one line of data.'); return; }
  if (!folder) { alert('Please enter a folder name.'); return; }
  const tabId = await getActiveTabId();
  if (!tabId) { alert('Could not detect an active tab.'); return; }

  await chrome.storage.local.set({ folder, lastData: dataInput, waitSeconds, breakEvery, breakSeconds });

  chrome.runtime.sendMessage({ 
    type: 'START_BATCH', 
    payload: { 
      lines, 
      folder, 
      tabId, 
      waitMs: Math.max(0, waitSeconds*1000),
      breakEvery: Math.max(0, breakEvery),
      breakMs: Math.max(0, breakSeconds*1000)
    } 
  });
  setUI({running:true, paused:false, progress:0, total:lines.length, status:'Starting…'});
});

document.getElementById('pauseResume').addEventListener('click', async () => {
  chrome.runtime.sendMessage({ type: 'TOGGLE_PAUSE' });
});

document.getElementById('stop').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'STOP_BATCH' });
});

// Restore last values
(async () => {
  const { folder, lastData, waitSeconds, breakEvery, breakSeconds } = await chrome.storage.local.get(['folder','lastData','waitSeconds','breakEvery','breakSeconds']);
  if (folder) document.getElementById('folderInput').value = folder;
  if (lastData) document.getElementById('dataInput').value = lastData;
  if (typeof waitSeconds === 'number') document.getElementById('waitSeconds').value = String(waitSeconds);
  if (typeof breakEvery === 'number') document.getElementById('breakEvery').value = String(breakEvery);
  if (typeof breakSeconds === 'number') document.getElementById('breakSeconds').value = String(breakSeconds);
})();

function removeProcessedLineFromTextarea(value) {
  const textarea = document.getElementById('dataInput');
  const lines = parseLines(textarea.value);
  const idx = lines.indexOf(String(value).trim());
  if (idx >= 0) {
    lines.splice(idx, 1);
    textarea.value = lines.join('\n');
    // persist
    chrome.storage.local.set({ lastData: textarea.value });
  }
}

// Listen for progress updates
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'BATCH_PROGRESS') {
    const { current, total, status, running, paused } = msg.payload;
    setUI({running, paused, progress: current, total, status});
  }
  if (msg?.type === 'BATCH_DONE') {
    setUI({running:false, paused:false, progress: msg.payload.total, total: msg.payload.total, status:'Done'});
  }
  if (msg?.type === 'BATCH_STOPPED') {
    const { current, total } = msg.payload;
    setUI({running:false, paused:false, progress: current, total, status:'Stopped'});
  }
  if (msg?.type === 'ITEM_DONE') {
    removeProcessedLineFromTextarea(msg.payload.value);
  }
  if (msg?.type === 'BATCH_PAUSED') {
    const { current, total, reason } = msg.payload;
    setUI({running:true, paused:true, progress: current, total, status: reason || 'Paused'});
  }
  if (msg?.type === 'BATCH_RESUMED') {
    const { current, total } = msg.payload;
    setUI({running:true, paused:false, progress: current, total, status: 'Resumed'});
  }
});
