# Batch PDF Filler & Downloader (Chrome Extension, MV3)

This extension automates filling a textarea and clicking a PDF generation button, then saves/renames each PDF into a chosen subfolder under your default Downloads directory. It runs through a list of inputs and shows a progress bar.

## What's new (v1.1.0)
- **Pause / Resume** button in the popup.
- **Scheduled breaks**: set “Break after how many items” and “Break duration (seconds)”. The run will automatically pause at intervals and resume after the break.
- **Auto-remove processed inputs**: when an item finishes, it is removed from the textarea list so you always see what’s left.

## What it does
- Fills `<textarea id="pn_data">` with each line of your provided data
- Clicks the button `<input type="button" id="pdfgenerate">`
- Waits for a fixed time you set (in seconds)
- Renames to `<folder>/<line>.pdf` (overwrites duplicates)
- **Clears the textarea on the page** before the next value
- **Removes the processed line from the popup list**
- Shows progress and allows **Pause/Resume** and **Stop**

## Permissions
- **downloads**: rename files into the folder you choose (under your default Downloads)
- **scripting**: injects a small content script to fill the form and click the button
- **activeTab** and **host_permissions**: to run on the active page you open

## Install (Developer Mode)
1. Download and unzip the archive.
2. Open **chrome://extensions** in Chrome.
3. Enable **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the unzipped folder.
5. Open your target webpage that contains the elements:
   - `#pn_data` (textarea)
   - `#pdfgenerate` (button)
6. Click the extension icon and open the popup:
   - Paste your data (one value per line).
   - Enter the **Download subfolder name** (inside your default Downloads).
   - Set **Wait after click**, optional **Break after N items**, and **Break duration**.
   - Press **Start**. You can Pause/Resume at any time. You can also press **Stop** to end early.

> The extension uses the text of each line as the filename. For example, if the line is `12345` and your folder is `Batch`, it saves as `Downloads/Batch/12345.pdf`.

## Files
- `manifest.json` – Extension config (MV3)
- `popup.html`, `popup.js` – UI: input list, options, progress, pause/resume
- `service_worker.js` – Orchestrates the batch, renames files, manages breaks
- `content.js` – Fills the textarea and clicks the button
- `icons/` – Icons
